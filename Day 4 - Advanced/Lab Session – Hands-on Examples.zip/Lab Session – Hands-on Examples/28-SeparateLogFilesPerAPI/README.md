# Lab 28 – One log file per API, named after the API (answer key)

Tested on WSO2 Integrator: MI 4.6.0 (JDK 21) on 2026-11-04, port offset 40. Uses `DelayBackend.java` from Lab 27. The log folder in the test was a folder outside MI_HOME (created beforehand).

| File | What it is |
|---|---|
| `ApiLogLabProject/` | `OrdersAPI` (/ordersapi/list), `InventoryAPI` (/inventoryapi/list), `PaymentsAPI` (/paymentsapi/list, for Step 4); all call `BackendEP` (3 s timeout) and have INFO, DEBUG and ERROR log mediators |
| `log4j2-api-logs-snippet.properties` | one Routing appender (file name from the event lookup for the logger name), the extra appenderRef on `API_LOGGER`, and the level of single APIs |
| `sample-requests.txt` | commands |

## Tested results
| Test | Result |
|---|---|
| Routing appender, OrdersAPI logger DEBUG, others INFO; one call to each API | files `API_LOGGER.OrdersAPI.log` (INFO + DEBUG) and `API_LOGGER.InventoryAPI.log` (INFO only) created in the folder |
| Backend 20 s | ERROR line `ERROR_CODE = 101504` in the file of the called API only |
| New API `PaymentsAPI` deployed (hot, no log4j2 change, no restart) | `API_LOGGER.PaymentsAPI.log` created at its first call |
| Levels changed in log4j2.properties while MI runs (about 50 s wait): Orders INFO, Inventory DEBUG | Orders file INFO only, Inventory file INFO + DEBUG |
| `wso2-mi-api.log` | still gets the lines of all APIs, including DEBUG of OrdersAPI |
| `wso2carbon.log` | gets the INFO/ERROR lines of the log mediator (`{api:OrdersAPI}`), no DEBUG lines |

## Findings
- The log mediator inside an API writes to the logger `API_LOGGER.<API name>` (docs page *Monitoring API-Level Logs*) and also to `org.apache.synapse.mediators.builtin.LogMediator`.
- The routing key (`$${event:Logger}`, the log4j2 event lookup) gives the logger name, so the file name is `API_LOGGER.<API name>.log`. The prefix `API_LOGGER.` was not removed (not tested with other lookups).
- Per-API appenders (one RollingFile appender and one logger per API, `additivity=false`) also work (first version of this lab, tested the same day), but need new lines for every new API.
- Not tested: `mi update log-level` for these loggers; log rotation (size/date); Windows paths.
