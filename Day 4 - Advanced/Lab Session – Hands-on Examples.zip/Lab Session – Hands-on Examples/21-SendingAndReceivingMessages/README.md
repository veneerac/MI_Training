# Lab 21 – MI as a JMS Producer and Consumer (answer key)

Answer key for `Lab 21 - MI as a JMS Producer and Consumer.docx`. **Tested on MI 4.6.0, ActiveMQ 5.19.1 and the Hospital backend on 2026-11-01.**

```
curl ─POST /hospitalservice/registerDoctor─▶ HospitalServiceApi ─▶ RegisterDoctorInSequence ─▶ JMS queue RegisterDoctorService
        ◀── 202 Accepted (at once) ──                    (JMS producer, OUT_ONLY)                         │
                                                                                                          ▼ poll every 1 s
Hospital backend ◀── HTTP POST /{hospital}/categories/admin/doctor/newdoctor ── AddDoctorSequence ◀── jms_inbound (JMS consumer)
```

| File | What it is |
|---|---|
| `JMSProducerConsumerProject/` | VS Code integration project. Build: `mvn clean package` (or **Build** in VS Code) → `target/JMSProducerConsumerProject_1.0.0.car` |
| `…/apis/HospitalServiceApi.xml` | `/hospitalservice`, `POST /registerDoctor` → `RegisterDoctorInSequence`, fault → `faultSequence` |
| `…/endpoints/RegisterDoctorServiceJMSEndpoint.xml` | `jms:/RegisterDoctorService?...` (queue, `tcp://localhost:61616`) |
| `…/sequences/RegisterDoctorInSequence.xml` | Log, `FORCE_SC_ACCEPTED`, `OUT_ONLY`, Call the JMS endpoint |
| `…/inbound-endpoints/jms_inbound.xml` | JMS listener on `RegisterDoctorService`, content type `application/json` |
| `…/sequences/AddDoctorSequence.xml` | Switch on `${payload.hospital}` → variable `hospital_name` → `http.post` to `HospitalConnection` |
| `…/sequences/AddDoctorErrorSequence.xml` | Error sequence of the consumer flow (added, see corrections) |
| `…/sequences/faultSequence.xml` | Fault sequence of the API |
| `…/local-entries/HospitalConnection.xml` | HTTP connection, base URL `http://localhost:9090` |
| `add_doctor.json` | Request payload |
| `deployment-toml-snippet.toml` | `[[transport.jms.sender]] myQueueSender` |

## Setup

1. ActiveMQ 5.19.1 running (`bin/activemq console`). Copy to `<MI_HOME>/lib`: `activemq-broker-5.19.1.jar`, `activemq-client-5.19.1.jar`, `activemq-kahadb-store-5.19.1.jar`, `hawtbuf-1.11.jar`, `slf4j-api-2.0.16.jar` (from `ACTIVEMQ_HOME/lib`) and `activeio-core-3.1.4.jar` (from `lib/optional`).
2. Add `deployment-toml-snippet.toml` to `<MI_HOME>/conf/deployment.toml`.
3. Hospital backend running: `java -jar Hospital-Service-JDK11-2.0.0.jar` (port 9090).
4. Copy the CAR to `<MI_HOME>/repository/deployment/server/carbonapps` and start MI.

```
curl -v -X POST http://localhost:8290/hospitalservice/registerDoctor -H "Content-Type: application/json" -d @add_doctor.json
```

## Tested results

| Test | Result |
|---|---|
| `add_doctor.json` (first time) | HTTP 202 at once; MI logs `Registering Doctor`, about 2 s later `Receiving Doctor Details` (from `jms_inbound`), then `{"status":"New Doctor Added Successfully"}` |
| Same request again | HTTP 202; backend answers `{"status":"Doctor Already Exist in the system"}` |
| Hospital `clemency medical center`, new name | Added to `clemency` |
| Unknown hospital (`city general hospital`) | HTTP 202; MI logs `WARN ... Doctor not registered: invalid hospital name` and drops the message |
| Queue `RegisterDoctorService` (ActiveMQ) | Enqueued = Dequeued, Pending 0 |

## Corrections to the lab doc

1. **Default branch of the Switch: Drop, not Respond.** The doc ends the default case with a Respond mediator. The consumer flow starts from a JMS inbound endpoint, which is one-way: there is no client to answer. Tested with the doc's version: `ERROR {Axis2Sender} - Inbound Response Sender not found - Inbound Endpoint may not support sending a response back`, then `faultSequence` runs, its Respond fails the same way, and the error repeats. The answer key logs the invalid message (WARN) and drops it.
2. **Separate error sequence for the consumer.** `faultSequence` ends with Respond, which is right for the API but fails in the JMS flow for the same reason. `jms_inbound` and `AddDoctorSequence` use `AddDoctorErrorSequence` (log + Drop).
3. **ActiveMQ 5.19.1 jar names.** The doc lists `hawtbuf-1.9.jar` and `Slf4j-api-1.6.6.jar`; ActiveMQ 5.19.1 ships `hawtbuf-1.11.jar` and `slf4j-api-2.0.16.jar` (used in the test).
4. **Endpoint URI typo.** The doc's URI contains `org.apache.activ emq.jndi...` (a space). It must be `org.apache.activemq.jndi.ActiveMQInitialContextFactory`.
5. **Sequence name.** The doc calls the consumer sequence both `AddDoctorSequence` and `addDoctorSequence`; the answer key uses `AddDoctorSequence`.
