# Lab 26 – Streaming Files using the VFS Transport (answer key)

Answer key for `Lab 26 - Streaming Files using the VFS Transport.docx`, which points to the WSO2 tutorial *File processing* (mi.docs.wso2.com/en/4.6.0/learn/integration-tutorials/file-processing/). Built from the tutorial, plus a proxy that **streams large files**. **Tested on MI 4.6.0 and MySQL 9.4 on 2026-11-01.**

```
FileProxy (VFS, *.txt, every 15 s)  in/ ──▶ Log ──▶ Clone ─┬─▶ fileWriteSequence ─▶ FileEp ─▶ out/<message-id>.txt
                                                           ├─▶ databaseSequence ─▶ Smooks (CSV → XML) ─▶ Iterate ─▶ DB Report ─▶ MySQL mi.info
                                                           └─▶ sendMailSequence ─▶ MailEp (optional, off by default)
                                    then in/ file ─▶ original/   (on error ─▶ failure/)

LargeFileStreamProxy (VFS, any file, every 5 s)  large-in/ ──stream──▶ LargeFileOutEp ─▶ large-out/<same name>   (source deleted)
```

| File | What it is |
|---|---|
| `FileProcessingProject/` | VS Code integration project. Build: `mvn clean package` → `target/FileProcessingProject_1.0.0.car` |
| `…/proxy-services/FileProxy.xml` | Tutorial proxy (VFS listener on `in`) |
| `…/sequences/fileWriteSequence.xml`, `databaseSequence.xml`, `sendMailSequence.xml` | Tutorial sequences |
| `…/endpoints/FileEp.xml`, `MailEp.xml` | `vfs:file:///tmp/mi-file-lab/out`, `mailto:` |
| `…/local-entries/smooks.xml` | Smooks CSV configuration (`name,surname,phone`), inline |
| `…/proxy-services/LargeFileStreamProxy.xml`, `…/endpoints/LargeFileOutEp.xml` | Large file streaming (added) |
| `setup-file-db.sql` | Database `mi`, table `info`, DB user `miuser` |
| `customers.txt` | Sample input (3 CSV lines) |
| `create-folders.sh` | Creates `/tmp/mi-file-lab/{in,out,original,failure,large-in,large-out}` |
| `deployment-toml-mail-snippet.toml` | Optional mail sender (tutorial's email part) |

## Setup

1. `mysql -u root -p < setup-file-db.sql`; copy `mysql-connector-j-8.2.0.jar` to `<MI_HOME>/lib`.
2. `sh create-folders.sh`. **Windows:** create `C:\mi-file-lab\...` and change the paths in the two proxies and two VFS endpoints to `file:///C:/mi-file-lab/...`.
3. Copy the CAR to `carbonapps` and start MI.
4. Copy `customers.txt` to `/tmp/mi-file-lab/in`. Large file: copy any big file to `/tmp/mi-file-lab/large-in`.

## Tested results

| Test | Result |
|---|---|
| `customers.txt` into `in` | Within 15 s: `out/<message-id>.txt` with the same 3 lines; 3 rows in `mi.info`; `customers.txt` moved to `original`; `failure` empty. Log: `sequence = fileWriteSequence`, `before-smooks`, `after-smooks` |
| 300 MB binary file into `large-in` | Copied to `large-out` with the **same SHA-1**; source deleted; old generation stayed at 110 307 KB during the whole transfer (the file is streamed, not loaded into the heap) |
| Email | **Not tested** (needs an SMTP account). The sequence and endpoint are in the project; see below |

## Changes from the tutorial

1. **No extra Smooks jar needed.** The tutorial copies `milyn-smooks-csv-1.2.4.jar`. MI 4.6.0's `smooks_1.5.1.wso2v5.jar` already contains `org.milyn.csv.CSVReader`; tested without the extra jar.
2. **Smooks configuration as an inline local entry** (`smooks.xml`) instead of `src="file:resources/smooks-config.xml"`, so it is deployed with the CAR.
3. **Table name `info` in lower case.** The tutorial creates `info` but inserts into `INFO`. That works on macOS/Windows MySQL but fails on Linux, where table names are case-sensitive.
4. **Drop instead of Respond** at the end of `fileWriteSequence` and `sendMailSequence`: a VFS proxy has no client to respond to.
5. **Email is off by default.** The tutorial clones to `sendMailSequence` too; without a configured mail sender that branch fails. To use it: add `deployment-toml-mail-snippet.toml`, set the address in `MailEp`, and uncomment the third target in `FileProxy`. The tutorial's sequence calls `MailEP` while the endpoint is named `MailEp`; the answer key uses `MailEp` in both.
6. **Large file streaming (added).** `LargeFileStreamProxy` uses `transport.vfs.Streaming=true` and content type `application/octet-stream` (BinaryRelayBuilder by default), and the body is never read in the flow. It must remove `ClientApiNonBlocking`: tested without it, the source file was deleted and the output file was **empty (0 bytes)**, because the listener deleted the file before the non-blocking call had streamed it.
