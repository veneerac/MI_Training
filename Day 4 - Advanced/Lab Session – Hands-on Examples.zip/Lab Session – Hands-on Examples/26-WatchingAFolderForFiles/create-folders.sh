#!/bin/sh
# Creates the folders used by FileProxy and LargeFileStreamProxy.
mkdir -p /tmp/mi-file-lab/in /tmp/mi-file-lab/out /tmp/mi-file-lab/original /tmp/mi-file-lab/failure \
         /tmp/mi-file-lab/large-in /tmp/mi-file-lab/large-out
ls /tmp/mi-file-lab
