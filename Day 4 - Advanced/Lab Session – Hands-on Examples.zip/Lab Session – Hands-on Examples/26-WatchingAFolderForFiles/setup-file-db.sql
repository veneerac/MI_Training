-- Lab 23: database for the file processing flow. Run as the MySQL root user:
--   mysql -u root -p < setup-file-db.sql
CREATE DATABASE IF NOT EXISTS mi;
CREATE USER IF NOT EXISTS 'miuser'@'localhost' IDENTIFIED BY 'miuser';
GRANT ALL PRIVILEGES ON mi.* TO 'miuser'@'localhost';
FLUSH PRIVILEGES;
USE mi;
CREATE TABLE IF NOT EXISTS info (
  name    VARCHAR(45) DEFAULT NULL,
  surname VARCHAR(45) DEFAULT NULL,
  phone   VARCHAR(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
