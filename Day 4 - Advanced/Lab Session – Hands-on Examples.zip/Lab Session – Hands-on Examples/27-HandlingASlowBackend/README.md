# Lab 27 – Endpoint Timeout, Endpoint Suspension and the Global Timeout (answer key)

Tested on WSO2 Integrator: MI 4.6.0 (JDK 21) on 2026-11-04, MI with port offset 40, backend on port 9090.

| File | What it is |
|---|---|
| `backend/DelayBackend.java` | Java backend, run with `java DelayBackend.java`. `GET /orders` answers after a delay, `POST /admin/delay?ms=` changes the delay while it runs |
| `TimeoutLabProject/` | MI project: endpoints `TimeoutOnlyEP`, `SuspendEP`, `NoTimeoutEP` (this one is the *broken* version of case 3), `TimeoutFaultSeq`, `OrdersAPI` (`/orders/timeout`, `/orders/suspend`, `/orders/global`) |
| `deployment-toml-snippet.toml` | `synapse.global_timeout_interval` (10 s for the lab) and `synapse.timeout_handler_interval` (1 s) |
| `sample-requests.txt` | all commands |

## Tested results
| Test | Result |
|---|---|
| Timeout 3 s, backend 20 s, default settings | 504 (101504) after 12–15 s: the timeout check runs every 15 s |
| Same, backend 6 s, default settings | 200 after 6 s: the 3 s timeout did not stop it |
| Same, `synapse.timeout_handler_interval = 1000` | 504 after 3.9–4.0 s |
| Backend 1 s | 200 after 1 s |
| SuspendEP, backend 20 s, 4 calls | 504, 504, 504 (about 4 s each), then 503 `303001` in milliseconds (SUSPENDED, 15 s) |
| Backend fast again, call at once | still 503 `303001` until the 15 s end, then 200 |
| Backend stopped | 503 `101503` at once, endpoint suspended after one failure; backend started again: 303001 for 15 s, then 200 |
| Management API `GET /management/endpoints` | `isActive:false` while suspended, `true` after |
| NoTimeoutEP, global timeout 10 s, backend 30 s | no answer (curl -m 25 gave up); WARN `Expiring message ... GLOBAL_TIMEOUT of : 10 seconds`; later WARN `a callback is not registered (anymore)`; no ERROR line, fault sequence not run |
| NoTimeoutEP with `<timeout>5000 fault`, same delay | 504 (101504) after 5.2 s |

## Findings
- `synapse.timeout_handler_interval` has no `[mediation]` key. It must be set in the `[synapse_properties]` section of `deployment.toml`. A line added by hand to `conf/synapse.properties` is removed at the next start (the file is generated from the toml).
- `synapse.global_timeout_interval` is set with `[mediation]` (key from `repository/resources/conf/key-mappings.json`).
- `markForSuspension` with `retriesBeforeSuspension = 2`: the endpoint was suspended by the **third** timeout.
- The listener socket timeout of MI (`http.socket.timeout` in `passthru-http.properties`) is 180000 ms: this is how long a client waits when the global timeout drops a call silently.
- Not tested: global timeout shorter than an endpoint timeout that has `responseAction fault`; MI CLI commands for endpoint state (the Management API was used).
