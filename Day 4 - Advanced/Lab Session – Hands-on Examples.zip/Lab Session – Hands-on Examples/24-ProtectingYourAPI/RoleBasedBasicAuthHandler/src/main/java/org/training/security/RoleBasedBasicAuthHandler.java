package org.training.security;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.synapse.MessageContext;
import org.apache.synapse.core.axis2.Axis2MessageContext;
import org.apache.synapse.core.axis2.Axis2Sender;
import org.apache.synapse.rest.Handler;
import org.wso2.micro.integrator.security.MicroIntegratorSecurityUtils;
import org.wso2.micro.integrator.security.user.api.UserStoreException;
import org.wso2.micro.integrator.security.user.api.UserStoreManager;

/**
 * Basic Auth handler for a REST API that also checks a role.
 *
 * Like the built-in RESTBasicAuthHandler, it authenticates the user against the MI user store.
 * In addition, the user must have the role given in the "allowedRole" handler property:
 *
 *   <handler class="org.training.security.RoleBasedBasicAuthHandler">
 *       <property name="allowedRole" value="reservations"/>
 *   </handler>
 *
 * Responses: 401 (with WWW-Authenticate) when the credentials are missing or wrong,
 * 403 when the user is valid but does not have the role. On success the user name is set in
 * the message property AUTHENTICATED_USER, so the API can log or use it.
 */
public class RoleBasedBasicAuthHandler implements Handler {

    private static final Log log = LogFactory.getLog(RoleBasedBasicAuthHandler.class);
    private static final String AUTH_HEADER = "Authorization";
    private static final String BASIC_PREFIX = "Basic ";

    private final Map<String, Object> properties = new HashMap<>();
    private String allowedRole;

    public void setAllowedRole(String allowedRole) {
        this.allowedRole = allowedRole;
    }

    @Override
    public boolean handleRequest(MessageContext messageContext) {
        org.apache.axis2.context.MessageContext axis2Ctx = ((Axis2MessageContext) messageContext).getAxis2MessageContext();
        Object headers = axis2Ctx.getProperty(org.apache.axis2.context.MessageContext.TRANSPORT_HEADERS);
        if (!(headers instanceof Map)) {
            return reject(messageContext, axis2Ctx, null, 401, "no transport headers");
        }
        Map headersMap = (Map) headers;
        Object authHeader = headersMap.get(AUTH_HEADER);
        if (authHeader == null || !authHeader.toString().startsWith(BASIC_PREFIX)) {
            return reject(messageContext, axis2Ctx, headersMap, 401, "Authorization header missing");
        }

        String decoded;
        try {
            decoded = new String(Base64.getDecoder().decode(authHeader.toString().substring(BASIC_PREFIX.length()).trim()),
                    StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return reject(messageContext, axis2Ctx, headersMap, 401, "Authorization header is not valid Base64");
        }
        int colon = decoded.indexOf(':');
        if (colon < 1) {
            return reject(messageContext, axis2Ctx, headersMap, 401, "credentials must be username:password");
        }
        String username = decoded.substring(0, colon);
        String password = decoded.substring(colon + 1);

        try {
            UserStoreManager userStore = MicroIntegratorSecurityUtils.getUserStoreManager();
            if (!userStore.authenticate(username, password)) {
                return reject(messageContext, axis2Ctx, headersMap, 401, "invalid username or password for " + username);
            }
            if (allowedRole != null && !Arrays.asList(userStore.getRoleListOfUser(username)).contains(allowedRole)) {
                return reject(messageContext, axis2Ctx, headersMap, 403, username + " does not have the role " + allowedRole);
            }
        } catch (UserStoreException e) {
            log.error("User store error while authenticating " + username, e);
            return reject(messageContext, axis2Ctx, headersMap, 401, "user store error");
        }
        messageContext.setProperty("AUTHENTICATED_USER", username);
        return true;
    }

    private boolean reject(MessageContext messageContext, org.apache.axis2.context.MessageContext axis2Ctx,
                           Map headersMap, int status, String reason) {
        log.warn("Request rejected with HTTP " + status + ": " + reason);
        if (headersMap != null) {
            headersMap.clear();
            if (status == 401) {
                headersMap.put("WWW-Authenticate", "Basic realm=\"WSO2 MI\"");
            }
        }
        axis2Ctx.setProperty("HTTP_SC", status);
        axis2Ctx.setProperty("NO_ENTITY_BODY", Boolean.TRUE);
        messageContext.setProperty("RESPONSE", "true");
        messageContext.setTo(null);
        Axis2Sender.sendBack(messageContext);
        return false;
    }

    @Override
    public boolean handleResponse(MessageContext messageContext) {
        return true;
    }

    @Override
    public void addProperty(String name, Object value) {
        properties.put(name, value);
        if ("allowedRole".equals(name)) {
            allowedRole = value == null ? null : value.toString();
        }
    }

    @Override
    public Map getProperties() {
        return properties;
    }
}
