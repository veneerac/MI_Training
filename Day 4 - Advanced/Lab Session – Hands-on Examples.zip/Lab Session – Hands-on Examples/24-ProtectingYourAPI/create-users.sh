#!/bin/sh
# Lab 22: creates the test users and the role through the MI Management API (the same calls the MI CLI makes).
#   receptionist / recep123  -> role "reservations"  (allowed by SecureReservationAPI)
#   visitor      / visit123  -> no role               (rejected by SecureReservationAPI with 403)
# Usage: sh create-users.sh [management-url] [admin-user] [admin-password]
MGMT="${1:-https://localhost:9164/management}"
ADMIN="${2:-admin}"
PASS="${3:-admin}"

TOKEN=$(curl -s -k -u "$ADMIN:$PASS" "$MGMT/login" | sed -E 's/.*"AccessToken":"([^"]+)".*/\1/')
[ -z "$TOKEN" ] && { echo "Login failed"; exit 1; }
call() { curl -s -k -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -X "$1" "$MGMT/$2" -d "$3"; echo; }

call POST users '{"userId":"receptionist","password":"recep123","isAdmin":"false"}'
call POST users '{"userId":"visitor","password":"visit123","isAdmin":"false"}'
call POST roles '{"role":"reservations"}'
call PUT  roles '{"userId":"receptionist","addedRoles":["reservations"]}'
curl -s -k -H "Authorization: Bearer $TOKEN" "$MGMT/users/receptionist"; echo
