-- Lab 22: user store database for the Micro Integrator.
-- Run as the MySQL root user, from <MI_HOME>:
--   mysql -u root -p < <path>/setup-userdb.sql
--   mysql -u root -p userdb < dbscripts/mysql/mysql_user.sql
CREATE DATABASE IF NOT EXISTS userdb;
CREATE USER IF NOT EXISTS 'userstore'@'localhost' IDENTIFIED BY 'userstore';
GRANT ALL PRIVILEGES ON userdb.* TO 'userstore'@'localhost';
FLUSH PRIVILEGES;
