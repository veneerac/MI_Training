# Lab 24 – Applying Security to a REST API (Basic Auth) (answer key)

Answer key for `Lab 24 - Applying Security to a REST API (Basic Auth).docx`, plus a **custom handler class** that adds a role check. **Tested on MI 4.6.0, MySQL 9.4 and the Hospital backend on 2026-11-01.**

| API | Context | Handler | Who gets in |
|---|---|---|---|
| `SecureHealthcareAPI` (lab doc) | `/securehealthcare` | Built-in `org.wso2.micro.integrator.security.handler.RESTBasicAuthHandler` | Any valid user in the user store |
| `SecureReservationAPI` (custom class) | `/securereservation` | `org.training.security.RoleBasedBasicAuthHandler`, property `allowedRole` = `reservations` | Valid users **with the role** `reservations` |

| File | What it is |
|---|---|
| `SecureHealthcareProject/` | VS Code integration project with both APIs. Build: `mvn clean package` → `target/SecureHealthcareProject_1.0.0.car` |
| `RoleBasedBasicAuthHandler/` | Maven project of the custom handler. Build: `mvn clean package` → `target/role-based-basic-auth-handler-1.0.0.jar` → copy to `<MI_HOME>/lib` |
| `setup-userdb.sql` | Creates the `userdb` database and the DB user `userstore` |
| `deployment-toml-snippet.toml` | User store settings (lab Step 2) |
| `create-users.sh` | Creates `receptionist` (role `reservations`) and `visitor` (no role) through the Management API |
| `reservation-request.json` | Request payload |

## Setup

1. `mysql -u root -p < setup-userdb.sql`, then from `<MI_HOME>`: `mysql -u root -p userdb < dbscripts/mysql/mysql_user.sql`. Copy `mysql-connector-j-8.2.0.jar` to `<MI_HOME>/lib`.
2. Apply `deployment-toml-snippet.toml` to `<MI_HOME>/conf/deployment.toml`.
3. Build `RoleBasedBasicAuthHandler` and copy its jar to `<MI_HOME>/lib`.
4. Copy the CAR to `carbonapps`, start MI, and log in once (creates the admin user): `curl -k -u admin:admin https://localhost:9164/management/login`.
5. `sh create-users.sh`

```
curl -v -X POST http://localhost:8290/securehealthcare/categories/surgery/reserve \
  -H "Content-Type: application/json" -u admin:admin -d @reservation-request.json
curl -v -X POST http://localhost:8290/securereservation/categories/surgery/reserve \
  -H "Content-Type: application/json" -u receptionist:recep123 -d @reservation-request.json
```

## Tested results

| API | Credentials | Result |
|---|---|---|
| `/securehealthcare` | none | **401**, `WWW-Authenticate: Basic realm="WSO2 EI"` |
| `/securehealthcare` | `admin:admin` | **200**, appointment from the backend (fee 7000) |
| `/securehealthcare` | `admin:wrong` | **403** (no body) |
| `/securehealthcare` | `receptionist:recep123` | **200** (the built-in handler checks no role) |
| `/securereservation` | none | **401**, `WWW-Authenticate: Basic realm="WSO2 MI"` |
| `/securereservation` | `visitor:wrong` | **401** |
| `/securereservation` | `visitor:visit123` (no role) | **403** |
| `/securereservation` | `admin:admin` (no `reservations` role) | **403** |
| `/securereservation` | `receptionist:recep123` | **200**; API log: `reservation for surgery, user receptionist` |

## The custom class

`RoleBasedBasicAuthHandler` implements the Synapse `Handler` interface, like the built-in handler. It authenticates against the MI user store (`MicroIntegratorSecurityUtils.getUserStoreManager().authenticate(...)`), then checks `getRoleListOfUser(...)` for the role in the handler property:

```xml
<handlers>
    <handler class="org.training.security.RoleBasedBasicAuthHandler">
        <property name="allowedRole" value="reservations"/>
    </handler>
</handlers>
```

It answers 401 (with `WWW-Authenticate`) for missing or wrong credentials, 403 for a valid user without the role, and sets the message property `AUTHENTICATED_USER` for the API.

**Deploy it to `<MI_HOME>/lib`, not in the CAR.** Tested: a handler class packed in the integration project (`src/main/java`, `…_class_mediators` in the CAR) fails with `ClassNotFoundException: org.training.security.RoleBasedBasicAuthHandler` and the CAR is rolled back. API handlers are created from the server class path; only `<class>` mediators can come from the CAR.

## Corrections to the lab doc

1. **Wrong password returns 403, not 401.** The doc says "Try a wrong password and check that you receive 401 Unauthorized again." The built-in `RESTBasicAuthHandler` answers **401 only when the `Authorization` header is missing**, and **403 Forbidden** for a wrong username or password (tested; also in its source code). The custom handler returns 401 for both.
2. **Management API port.** `https://localhost:9164` assumes the default offset 10.
