<!--
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<%-- Workaround for https://ops4j1.jira.com/browse/PAXWEB-1070 --%>
<%@include file="WEB-INF/jspf/headertags.jspf" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>Apache ActiveMQ</title>
    <link rel="stylesheet" media="screen" href="/styles/head.css" />
</head>

<body>


<div class="white_box">
    <div class="header">
        <div class="header_l">
            <div class="header_r">
            </div>
        </div>
    </div>
    <div class="content">
        <div class="content_l">
            <div class="content_r">

                <div>

                    <!-- Banner -->
                    <div id="asf_logo">
                        <div id="activemq_logo">
                            <a class="header-logo-active-mq"
                               href="http://activemq.apache.org/"
                               title="The most popular and powerful open source Message Broker">ActiveMQ</a>
                            <a class="header-logo-apache"
                               href="http://www.apache.org/" title="The Apache Software Foundation">ASF</a>
                        </div>
                    </div>


                    <div class="top_red_bar">
                        <div id="site-breadcrumbs">
                        </div>
                        <div id="site-quicklinks"><p>
                            <a href="http://activemq.apache.org/support.html"
                               title="Get help and support using Apache ActiveMQ">Support</a></p>
                        </div>
                    </div>

                    <table border="0">
                        <tbody>
                            <tr>
                                <td valign="top" width="100%" class="body-container">
                                    <div class="body-content">
                                        <p align="center">Broker is currently in <b>slave</b> mode!</p>
                                    </div>
                                </td>
                                <td valign="top">

                                    <div class="navigation">
                                        <div class="navigation_top">
                                            <div class="navigation_bottom">
                                                <h3>Useful Links</h3>

                                                <ul class="alternate" type="square">
                                                    <li><a href="http://activemq.apache.org/"
                                                           title="The most popular and powerful open source Message Broker">Documentation</a></li>
                                                    <li><a href="http://activemq.apache.org/faq.html">FAQ</a></li>
                                                    <li><a href="http://activemq.apache.org/download.html">Downloads</a>
                                                    </li>
                                                    <li><a href="http://activemq.apache.org/discussion-forums.html">Forums</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>


                    <div class="bottom_red_bar"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="black_box">
        <div class="footer">
            <div class="footer_l">
                <div class="footer_r">
                    <div>
                        Copyright 2005-2024 The Apache Software Foundation.

                        (<a href="?printable=true">printable version</a>)
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="design_attribution"><a href="http://hiramchirino.com/">Graphic Design By Hiram</a></div>

</body>
</html>
